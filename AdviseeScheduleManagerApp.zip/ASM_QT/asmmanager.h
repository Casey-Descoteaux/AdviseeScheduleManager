#ifndef ASMMANAGER_H
#define ASMMANAGER_H

#include <QSqlDatabase>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlRecord>
#include <QString>
#include <QVariant>
#include <string>
#include <vector>
#include "course.h"
#include "advisee.h"

using std::string;
using std::vector;

class asmManager
{
public:
    //Constructor
    asmManager();

    //Load courses from database
    void loadCourses();
    //Transfer courses to asm_main
    vector<course> getCourses();

    //Load advisees
    void loadAdvisees();
    //Transfer advisees to asm_main
    vector<advisee> getAdvisees();

    //Load schedule
    void selectSchedule(advisee);
    //Transer scheudle to asm_main
    vector<course> getSchedule();

    //Add a course to the schedule table
    void addCourse(course, advisee);
    //Drops a course from the schedule table
    void dropCourse(course, advisee);

    //Gets the personal info for the selected advisee
    void setPersonalInfo(advisee);
    //Transfer personal to asm_main
    vector<string> getPersonalInfo();

    ~asmManager();

private:
    //Database
    QSqlDatabase db;

    //Used to populate the course table
    course nextCourse;
    vector<course> courses;

    //Used to populate the advisee table
    advisee nextAdvisee;
    vector<advisee> advisees;

    //Used to populate the schedule table depending on the advisee selected
    course nextInSchedule;
    vector<course> schedule;

    //Used to store the advisee personal information
    vector<string> personalInformation;
};

#endif // ASMMANAGER_H
