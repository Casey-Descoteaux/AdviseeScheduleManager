#include "asm_main.h"
#include "ui_asm_main.h"

ASM_Main::ASM_Main(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ASM_Main)
{
    ui->setupUi(this);

    //Create an adviseeModel and assign it to the adviseeList widget
    aModel = new adviseeModel(this);
    aModel->setAdvisees(manager.getAdvisees());
    ui->adviseeTable->setModel(aModel);
    // Set the table view to allow the columns to expand
    ui->adviseeTable->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    // Stretch the column headers to fit the width of the table view
    ui->adviseeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    // Resize the columns
    ui->adviseeTable->resizeColumnsToContents();
    //Adjust the columns to fit the contents
    ui->adviseeTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->adviseeTable->horizontalHeader()->setStretchLastSection(true);

    //Create a courseModel and assign it to the courseTable widget
    cModel = new courseModel(this);
    cModel->setCourses(manager.getCourses());
    ui->courseTable->setModel(cModel);
    //Set the table view to allow the columns to expand
    ui->courseTable->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    //Stretch the column headers to fit the width of the table view
    ui->courseTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    //Resize the columns
    ui->courseTable->resizeColumnsToContents();
    //Adjust the columns to fit the contents
    ui->courseTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->adviseeTable->horizontalHeader()->setStretchLastSection(true);

    //Create a scheduleModel and assign it to the adviseeSchedule widget
    sModel = new courseModel(this);
    //sModel->setCourses(manager.getSchedule());
    ui->adviseeSchedule->setModel(sModel);
    //Set the table view to allow the columns to expand
    ui->adviseeSchedule->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    //Stretch the column headers to fit the width of the table view
    ui->adviseeSchedule->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    //Resize the columns
    ui->adviseeSchedule->resizeColumnsToContents();
}

ASM_Main::~ASM_Main()
{
    //Deletes the models and the ui when the program is closed
    delete aModel;
    delete cModel;
    delete sModel;
    delete ui;
}

void ASM_Main::on_moreInfoButton_clicked()
{
    this->openMoreInfo();
}

void ASM_Main::openMoreInfo()
{
    personalInfoDisplay infoDisplay(this);

    infoDisplay.displayHasRoommate();
    infoDisplay.displayResHall();
    infoDisplay.displayEmail();
    infoDisplay.displayAddress();
    infoDisplay.displayID();
    infoDisplay.displayFullTime();
    infoDisplay.exec();
}

void ASM_Main::on_addCourseButton_clicked()
{
    //Determines the course that the advisor has selected
    QModelIndex index = ui->courseTable->selectionModel()->currentIndex();
    int row = index.row();
    //Determines the advisee that is selected
    QModelIndex adviseeIndex = ui->adviseeTable->selectionModel()->currentIndex();
    int adviseeRow = adviseeIndex.row();

    //Tests if a course and an advisee have been selected
    if(row >= 0 && adviseeRow >= 0)
    {
        //Gets the course being selected
        vector<course> courses = manager.getCourses();
        course wanted = courses[row];

        for(auto i = manager.getSchedule().begin(); i != manager.getSchedule().end(); i++)
        {
            if(wanted.getCourseCRN() == i->getCourseCRN())
            {
                QMessageBox error;
                error.setText("This advisee is already in this course");
                error.exec();
                return;
            }
            if(wanted.getSection() == i->getSection())
            {
                QMessageBox error;
                error.setText("This advisee already has a course during this section");
                error.exec();
                return;
            }
        }

        //Gets confirmation that the course is going to be added to the advisee's schedule
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Add Course", "Are you sure you want to add this course?",
                                  QMessageBox::Yes|QMessageBox::No);
        if(reply == QMessageBox::Yes)
        {
            //gets the advisee being selected
            vector<advisee> advisees = manager.getAdvisees();
            advisee aInUse = advisees[adviseeRow];
            //Inserts the course into the advisee schedule
            manager.addCourse(wanted, aInUse);
            //Refreshes the schedule block
            manager.selectSchedule(aInUse);
            sModel->setCourses(manager.getSchedule());
            ui->adviseeSchedule->setModel(sModel);
        }
    }
        else
        {
            QMessageBox error;
            error.setText("No course and/or advisee selected");
            error.exec();
        }
}

void ASM_Main::on_dropCourseButton_clicked()
{
    //Determines the row containing the class to be removed
    QModelIndex index = ui->adviseeSchedule->selectionModel()->currentIndex();
    int row = index.row();
    //Determines the advisee that is selected
    QModelIndex adviseeIndex = ui->adviseeTable->selectionModel()->currentIndex();
    int adviseeRow = adviseeIndex.row();

    if(row >= 0 && adviseeRow >= 0)
    {
        //Gets confirmation that the course is going to be dropped from the advisee schedule
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Drop Course", "Are you sure you want to remove this course form the schedule?",
                                  QMessageBox::Yes|QMessageBox::No);
        if(reply == QMessageBox::Yes)
        {
            //Gets the course being selected
            vector<course> coursesInSchedule = manager.getSchedule();
            course wantRemoved = coursesInSchedule[row];
            //Gets the advisee being selected
            vector<advisee> advisees = manager.getAdvisees();
            advisee aInUse = advisees[adviseeRow];
            //Drops the course from the advisee schedule
            manager.dropCourse(wantRemoved, aInUse);
            //Refreshes the schedule block
            manager.selectSchedule(aInUse);
            sModel->setCourses(manager.getSchedule());
            ui->adviseeSchedule->setModel(sModel);
        }
    }
    else
    {
        QMessageBox error;
        error.setText("No course from schedule and/or advisee selected");
        error.exec();
    }
}

void ASM_Main::on_adviseeTable_clicked(const QModelIndex &index)
{
    personalInfoDisplay infoDisplay(this);
    //Get the advisee and their schedule
    int row = index.row();
    vector<advisee> all = manager.getAdvisees();
    advisee inUse = all[row];
    manager.selectSchedule(inUse);
    sModel->setCourses(manager.getSchedule());
    //Adjust the columns to fit the contents
    ui->adviseeSchedule->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->adviseeSchedule->horizontalHeader()->setStretchLastSection(false);

    manager.setPersonalInfo(inUse);
    vector<string> personalInfo = manager.getPersonalInfo();
    infoDisplay.setID(personalInfo[0]);
    infoDisplay.setIsFullTime(personalInfo[1]);
    infoDisplay.setHasRoommate(personalInfo[2]);
    infoDisplay.setResHall(personalInfo[3]);
    infoDisplay.setAddress(personalInfo[4]);
    infoDisplay.setEmail(personalInfo[5]);
}
