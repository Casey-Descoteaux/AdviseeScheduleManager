#include "course.h"

course::course()
{
}

//Course getters
string course::getName() const
{
    return cName;
}

string course::getCourseNum() const
{
    return cNum;
}

string course::getCourseCRN() const
{
    return cCRN;
}

string course::getCredits() const
{
    return cCredits;
}

string course::getRoom() const
{
    return cRoom;
}

string course::getSection() const
{
    return cSection;
}

string course::getProf() const
{
    return cProf;
}

string course::getTerm() const
{
    return cTerm;
}

string course::getDayOffered() const
{
    return cDayOffered;
}

string course::getMaxEnroll() const
{
    return cMaxEnroll;
}

//Course setters
void course::setName(string name)
{
    cName = name;
}

void course::setCourseNum(string num)
{
    cNum = num;
}

void course::setCourseCRN(string CRN)
{
    cCRN = CRN;
}

void course::setCredits(string credits)
{
    cCredits = credits;
}

void course::setRoom(string room )
{
    cRoom = room;
}

void course::setSection(string section)
{
    cSection = section;
}

void course::setProf(string prof)
{
    cProf = prof;
}

void course::setTerm(string term)
{
    cTerm = term;
}

void course::setDayOffered(string dayOffered)
{
    cDayOffered = dayOffered;
}

void course::setMaxEnroll(string maxEnroll)
{
    cMaxEnroll = maxEnroll;
}

course::~course()
{
}

