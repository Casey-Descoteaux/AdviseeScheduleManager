#ifndef ADVISEE_H
#define ADVISEE_H

#include "course.h"

#include <string>
#include <vector>

using std::string;
using std::vector;

class advisee
{
public:
    //constructor
    advisee();

    //adivsee getters
    string getFName()const;
    string getLName()const;
    string getID()const;
    string getClassYear()const;
    string getCredits()const;
    string getMajor()const;
    string getAdvisorName()const;

    //advisee setters
    void setFName(string);
    void setLName(string);
    void setID(string);
    void setClassYear(string);
    void setCredits(string);
    void setMajor(string);
    void setAdvisorName(string);

    ~advisee();

private:
    string fName;
    string lName;
    string ID;
    string classYear;
    string credits;
    string major;
    string advisorName;
};

#endif
