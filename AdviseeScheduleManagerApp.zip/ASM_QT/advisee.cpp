#include "advisee.h"

//Constructor
advisee::advisee()
{
}

//Advisee getters
string advisee::getFName() const
{
    return fName;
}

string advisee::getLName() const
{
    return lName;
}

string advisee::getID() const
{
    return ID;
}

string advisee::getClassYear() const
{
    return classYear;
}

string advisee::getCredits() const
{
    return credits;
}

string advisee::getMajor() const
{
    return major;
}

string advisee::getAdvisorName() const
{
    return advisorName;
}

//advisee setters
void advisee::setFName(string first)
{
    fName = first;
}

void advisee::setLName(string last)
{
    lName = last;
}

void advisee::setID(string sID)
{
    ID = sID;
}

void advisee::setClassYear(string year)
{
    classYear = year;
}

void advisee::setCredits(string cred)
{
    credits = cred;
}

void advisee::setMajor(string maj)
{
    major = maj;
}

void advisee::setAdvisorName(string aName)
{
    advisorName = aName;
}

advisee::~advisee()
{
}

