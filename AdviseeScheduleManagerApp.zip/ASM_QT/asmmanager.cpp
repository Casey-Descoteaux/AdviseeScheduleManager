#include "asmmanager.h"

asmManager::asmManager()
{
    //Opens a database connection and keeps it open for the duration the application is open
    db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("Driver={ODBC Driver 13 for SQL Server};Server=tcp:asm-courses.database.windows.net,1433;Database=advisee_manager;Uid=descoteauxc;Pwd=Whysoserious4;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;");
    if(db.open())
    {
        this->loadCourses();
        this->loadAdvisees();
    }
}

asmManager::~asmManager()
{
    db.close();
}

vector<course> asmManager::getCourses()
{
    return courses;
}

void asmManager::loadCourses()
{
    //Select statement to get all of the courses in the database
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare("SELECT * FROM courses");
    if(query.exec())
    {
        while(query.next())
        {
            string CRN = query.value(0).toString().toStdString();
            string num = query.value(1).toString().toStdString();
            string name = query.value(2).toString().toStdString();
            string section = query.value(3).toString().toStdString();
            string term = query.value(4).toString().toStdString();
            string dayOffered = query.value(5).toString().toStdString();
            string room = query.value(6).toString().toStdString();
            string credits = query.value(7).toString().toStdString();
            string prof = query.value(8).toString().toStdString();
            string maxEnroll = query.value(9).toString().toStdString();

            nextCourse.setCourseCRN(CRN);
            nextCourse.setCourseNum(num);
            nextCourse.setName(name);
            nextCourse.setSection(section);
            nextCourse.setTerm(term);
            nextCourse.setDayOffered(dayOffered);
            nextCourse.setRoom(room);
            nextCourse.setCredits(credits);
            nextCourse.setProf(prof);
            nextCourse.setMaxEnroll(maxEnroll);

            courses.push_back(nextCourse);
        }
    }
}

vector<advisee> asmManager::getAdvisees()
{
    return advisees;
}

void asmManager::loadAdvisees()
{
    //Select statement to get all of the advisees in the database
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare("SELECT * FROM advisees");
    if(query.exec())
    {
        while(query.next())
        {
            string fName = query.value(0).toString().toStdString();
            string lName = query.value(1).toString().toStdString();
            string ID = query.value(2).toString().toStdString();
            string classYear = query.value(3).toString().toStdString();
            string credits = query.value(4).toString().toStdString();
            string major = query.value(5).toString().toStdString();
            string advisorName = query.value(6).toString().toStdString();

            nextAdvisee.setFName(fName);
            nextAdvisee.setLName(lName);
            nextAdvisee.setID(ID);
            nextAdvisee.setClassYear(classYear);
            nextAdvisee.setCredits(credits);
            nextAdvisee.setMajor(major);
            nextAdvisee.setAdvisorName(advisorName);

            advisees.push_back(nextAdvisee);
        }
    }
}

vector<course> asmManager::getSchedule()
{
    return schedule;
}

void asmManager::selectSchedule(advisee inUse)
{
    schedule.clear();

    //Prepares a select statement to get an advisee schedule
    QString getAdivseeSchedule = "SELECT * FROM schedule WHERE ID = ?";
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare(getAdivseeSchedule);

    //Assign the advisee ID to the ? value
    query.bindValue(0, QString::fromStdString(inUse.getID()));

    if(query.exec())
    {
        while(query.next())
        {
            string CRN = query.value(0).toString().toStdString();
            string num = query.value(1).toString().toStdString();
            string name = query.value(2).toString().toStdString();
            string section = query.value(3).toString().toStdString();
            string term = query.value(4).toString().toStdString();
            string dayOffered = query.value(5).toString().toStdString();
            string room = query.value(6).toString().toStdString();
            string credits = query.value(7).toString().toStdString();
            string prof = query.value(8).toString().toStdString();
            string maxEnroll = query.value(9).toString().toStdString();

            nextInSchedule.setCourseCRN(CRN);
            nextInSchedule.setCourseNum(num);
            nextInSchedule.setName(name);
            nextInSchedule.setSection(section);
            nextInSchedule.setTerm(term);
            nextInSchedule.setDayOffered(dayOffered);
            nextInSchedule.setRoom(room);
            nextInSchedule.setCredits(credits);
            nextInSchedule.setProf(prof);
            nextInSchedule.setMaxEnroll(maxEnroll);

            schedule.push_back(nextInSchedule);
        }
    }
}

void asmManager::addCourse(course wanted, advisee inUse)
{
    //Prepares an insert statement
    QString insert;
    insert += "INSERT INTO schedule (sCRN, sNum, sName, sSection, sTerm, sDayOffered, sRoom, sCredits, sProf, sMaxEnroll, ID) ";
    insert += "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare(insert);

    //Assigning the eleven ? values for the insert
    query.bindValue(0, QString::fromStdString(wanted.getCourseCRN()));
    query.bindValue(1, QString::fromStdString(wanted.getCourseNum()));
    query.bindValue(2, QString::fromStdString(wanted.getName()));
    query.bindValue(3, QString::fromStdString(wanted.getSection()));
    query.bindValue(4, QString::fromStdString(wanted.getTerm()));
    query.bindValue(5, QString::fromStdString(wanted.getDayOffered()));
    query.bindValue(6, QString::fromStdString(wanted.getRoom()));
    query.bindValue(7, QString::fromStdString(wanted.getCredits()));
    query.bindValue(8, QString::fromStdString(wanted.getProf()));
    query.bindValue(9, QString::fromStdString(wanted.getMaxEnroll()));
    query.bindValue(10, QString::fromStdString(inUse.getID()));

    query.exec();
}

void asmManager::dropCourse(course toRemove, advisee inUse)
{
    //Prepare a delete statement
    QString drop = "DELETE FROM schedule WHERE sCRN = ? AND ID = ?";
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare(drop);

    //Assigning the two ? values for the delete
    query.bindValue(0, QString::fromStdString(toRemove.getCourseCRN()));
    query.bindValue(1, QString::fromStdString(inUse.getID()));

    query.exec();
}

void asmManager::setPersonalInfo(advisee inUse)
{
    personalInformation.clear();

    //Prepares a select statement
    QString getPersonalInfo = "SELECT * FROM adviseePersonalInfo WHERE ID = ?";
    QSqlQuery query;
    query.setForwardOnly(true);
    query.prepare(getPersonalInfo);

    //Assigning the ? value for the select
    query.bindValue(0, QString::fromStdString(inUse.getID()));

    if(query.exec())
    {
       while(query.next())
       {
            string ID = query.value(0).toString().toStdString();
            string fullTime = query.value(1).toString().toStdString();
            string roommate = query.value(2).toString().toStdString();
            string resHall = query.value(3).toString().toStdString();
            string homeAddress = query.value(4).toString().toStdString();
            string email = query.value(5).toString().toStdString();

            personalInformation.push_back(ID);
            personalInformation.push_back(fullTime);
            personalInformation.push_back(roommate);
            personalInformation.push_back(resHall);
            personalInformation.push_back(homeAddress);
            personalInformation.push_back(email);
        }
    }
}

vector<string> asmManager::getPersonalInfo()
{
    return personalInformation;
}
