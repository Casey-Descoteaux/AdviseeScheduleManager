#ifndef COURSE_H
#define COURSE_H

#include<string>
#include <vector>

using std::string;
using std::vector;

class course
{
public:
    //Constructor
    course();

    //Course getters
    string getName() const;
    string getCourseNum() const;
    string getCourseCRN() const;
    string getCredits() const;
    string getRoom() const;
    string getSection() const;
    string getProf() const;
    string getTerm() const;
    string getDayOffered() const;
    string getMaxEnroll() const;

    //Course setters
    //Called to create course objects from database info
    void setName(string);
    void setCourseNum(string);
    void setCourseCRN(string);
    void setCredits(string);
    void setRoom(string);
    void setSection(string);
    void setProf(string);
    void setTerm(string);
    void setDayOffered(string);
    void setMaxEnroll(string);

    ~course();

private:
    string cName;
    string cNum;
    string cCRN;
    string cCredits;
    string cRoom;
    string cSection;
    string cProf;
    string cTerm;
    string cDayOffered;
    string cMaxEnroll;
};

#endif
