    #include "personalinfodisplay.h"
    #include "ui_personalinfodisplay.h"
    #include "asm_main.h"
    #include "ui_asm_main.h"

    #include <QMessageBox>
    #include <string>

    using std::string;

    personalInfoDisplay::personalInfoDisplay(QWidget *parent) :
        QDialog(parent),
        ui(new Ui::personalInfoDisplay)
    {
        ui->setupUi(this);
    }

    //Go into the database and return the advisee fields and assign them to the labels
    void personalInfoDisplay::setID(string ID)
    {
        sID = ID;
    }

    void personalInfoDisplay::setIsFullTime(string isFullTime)
    {
        sIsFullTime = isFullTime;
    }

    void personalInfoDisplay::setHasRoommate(string roommate)
    {
        sRoommate = roommate;
    }

    void personalInfoDisplay::setResHall(string resHall)
    {
        sResHall = resHall;
    }

    void personalInfoDisplay::setEmail(string email)
    {
        sEmail = email;
    }

    void personalInfoDisplay::setAddress(string address)
    {
        sAddress = address;
    }

    void personalInfoDisplay::displayID()
    {
        ui->idDisplay->setText(QString::fromStdString(sID));
    }

    void personalInfoDisplay::displayFullTime()
    {
        ui->ftsDisplay->setText(QString::fromStdString(sIsFullTime));
    }

    void personalInfoDisplay::displayHasRoommate()
    {
        ui->roommateDisplay->setText(QString::fromStdString(sRoommate));
    }

    void personalInfoDisplay::displayResHall()
    {
        ui->housingDisplay->setText(QString::fromStdString(sResHall));
    }

    void personalInfoDisplay::displayEmail()
    {
        ui->emailDisplay->setText(QString::fromStdString(sEmail));
    }

    void personalInfoDisplay::displayAddress()
    {
        ui->addressDisplay->setText(QString::fromStdString(sAddress));
    }

    personalInfoDisplay::~personalInfoDisplay()
    {
        delete ui;
    }

