#include "coursemodel.h"
#include "course.h"

#include <vector>
#include <QBrush>
#include <QColor>
#include <QFont>

courseModel::courseModel(QObject *parent)
    : QAbstractTableModel(parent)
{
}

void courseModel::setCourses(vector<course> all)
{
    courses = all;
    this->setData(this->index(0, 0), 0);
}

QVariant courseModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    {
        if (role == Qt::DisplayRole)
        {
            // Set the column (Qt::Horizontal) headers
            if (orientation == Qt::Horizontal) {
                switch (section)
                {
                case 0:
                    return QString("CRN");
                case 1:
                    return QString("Number");
                case 2:
                    return QString("Name");
                case 3:
                    return QString("Section");
                case 4:
                    return QString("Term");
                case 5:
                    return QString("Days Offered");
                case 6:
                    return QString("Room");
                case 7:
                    return QString("Credits");
                case 8:
                    return QString("Professor");
                case 9:
                    return QString("Max Class Size");
                }
            }
        }
        return QVariant();
    }
}

int courseModel::rowCount(const QModelIndex &parent) const
{
    return courses.size();
}

int courseModel::columnCount(const QModelIndex &parent) const
{
    return 10;
}

QVariant courseModel::data(const QModelIndex &index, int role) const
{
    // Get the row and columns numbers from the given index (QModelIndex)
    int row = index.row();
    int col = index.column();

    // Qt::DisplayRole -> what data do we display and in what columns?
    if (role == Qt::DisplayRole)
    {
        switch (col)
        {
        case 0: // CRN column
            return QString::fromStdString(courses[row].getCourseCRN());
            break;
        case 1: // Number column
            return QString::fromStdString(courses[row].getCourseNum());
            break;
        case 2: // Name column
            return QString::fromStdString(courses[row].getName());
            break;
        case 3: // Section column
            return QString::fromStdString(courses[row].getSection());
            break;
        case 4: // Term column
            return QString::fromStdString(courses[row].getTerm());
            break;
        case 5: // Days Offered column
            return QString::fromStdString(courses[row].getDayOffered());
            break;
        case 6: // Room column
            return QString::fromStdString(courses[row].getRoom());
            break;
        case 7: //Credits column
            return QString::fromStdString(courses[row].getCredits());
            break;
        case 8: //Professor column
            return QString::fromStdString(courses[row].getProf());
            break;
        case 9: //Maximum Enrollment column
            return QString::fromStdString(courses[row].getMaxEnroll());
            break;
        }
    }

    // Qt::FontRole -> manages the fonts and font styles used in the View
    else if (role == Qt::FontRole)
    {
        // Bold the text in the first column
        if (col == 0) {
            QFont boldFont;
            boldFont.setBold(true);
            return boldFont;
        }
    }

    // Qt::ForegroundRole -> paints the foreground (text) colors
    else if (role == Qt::ForegroundRole)
    {
        // Paint the text red in the Password column
        if (col == 1) {
           return QBrush(QColor(0,0,0));
        }
    }

    // Qt::TextAlignRole -> controls how data is aligned inside cells
    else if(role == Qt::TextAlignmentRole)
    {
        // All columns after the Username column should be right-aligned
        // horizontally, and centered vertically.
        if (col > 0)
        {
            return Qt::AlignRight + Qt::AlignVCenter;
        }
    }
    return QVariant();
}

bool courseModel::setData(QModelIndex const& idx, QVariant const& value, int role)
{
  // Qt::EditRole: manages changes in the model
  if (Qt::EditRole == role)
  {
    // Get the top left and bottom right indices of the cells in our update range
    QModelIndex topLeft = idx;
    QModelIndex bottomRight = index(this->rowCount() - 1, this->columnCount() - 1);

    // VERY IMPORTANT - emit events telling all listening event handlers
    // that both the data (from cell 0,0 to the end) AND the layout have changed
    emit dataChanged(topLeft, bottomRight);
    emit layoutChanged();

    return true;
  }
  return false;
}
