#ifndef ASM_MAIN_H
#define ASM_MAIN_H

#include <QMainWindow>
#include <QItemSelection>
#include <QMessageBox>
#include "adviseemodel.h"
#include "coursemodel.h"
#include "personalinfodisplay.h"
#include "asmmanager.h"

namespace Ui {
class ASM_Main;
}

class ASM_Main : public QMainWindow
{
    Q_OBJECT

public:
    explicit ASM_Main(QWidget *parent = 0);
    ~ASM_Main();

private slots:
    void on_moreInfoButton_clicked();

    void on_addCourseButton_clicked();

    void on_dropCourseButton_clicked();

    void on_adviseeTable_clicked(const QModelIndex &index);

private:
    Ui::ASM_Main *ui;
    asmManager manager;
    adviseeModel *aModel;
    courseModel *cModel;
    courseModel *sModel;
    void openMoreInfo();
};

#endif // ASM_MAIN_H
