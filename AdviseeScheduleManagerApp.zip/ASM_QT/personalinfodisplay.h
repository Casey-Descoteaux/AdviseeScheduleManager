#ifndef PERSONALINFODISPLAY_H
#define PERSONALINFODISPLAY_H

#include <QDialog>
#include <string>

using std::string;

namespace Ui {
class personalInfoDisplay;
}

class personalInfoDisplay : public QDialog
{
    Q_OBJECT

public:
    explicit personalInfoDisplay(QWidget *parent = 0);
    ~personalInfoDisplay();

    //Personal information getter methods
    //Called to set the label fields to display the personal info for the selected advisee
    void setID(string);
    void setIsFullTime(string);
    void setHasRoommate(string);
    void setResHall(string);
    void setEmail(string);
    void setAddress(string);

    //Called to display the contents to the labels
    void displayID();
    void displayFullTime();
    void displayHasRoommate();
    void displayResHall();
    void displayEmail();
    void displayAddress();

private:
    string sID;
    string sIsFullTime;
    string sRoommate;
    string sResHall;
    string sEmail;
    string sAddress;
    Ui::personalInfoDisplay *ui;
};

#endif // PERSONALINFODISPLAY_H
