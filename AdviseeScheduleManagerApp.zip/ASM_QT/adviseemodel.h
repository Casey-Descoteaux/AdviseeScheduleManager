#ifndef ADVISEEMODEL_H
#define ADVISEEMODEL_H

#include <QAbstractTableModel>
#include <vector>
#include <string>
#include <advisee.h>

using std::vector;
using std::string;

class adviseeModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vector<advisee> advisees;

public:
    explicit adviseeModel(QObject *parent = 0);

    // Overrides methods inherited from QAbstractTableModel
    virtual int rowCount(const QModelIndex &parent = QModelIndex()) const;
    virtual int columnCount(const QModelIndex &parent = QModelIndex()) const;
    virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    virtual bool setData(const QModelIndex & index, const QVariant & value, int role = Qt::EditRole);

    void setAdvisees(vector<advisee>);

signals:

private slots:
};

#endif // ADVISEEMODEL_H
