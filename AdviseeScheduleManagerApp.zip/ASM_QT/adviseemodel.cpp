#include <vector>
#include <QBrush>
#include <QColor>
#include <QFont>
#include "adviseemodel.h"
#include "advisee.h"

adviseeModel::adviseeModel(QObject *parent)
    : QAbstractTableModel(parent)
{
}

void adviseeModel::setAdvisees(vector<advisee> all)
{
    advisees = all;
}

QVariant adviseeModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    {
        if (role == Qt::DisplayRole)
        {
            // Set the column (Qt::Horizontal) headers
            if (orientation == Qt::Horizontal) {
                switch (section)
                {
                case 0:
                    return QString("First Name");
                case 1:
                    return QString("Last Name");
                case 2:
                    return QString("Student ID");
                case 3:
                    return QString("Class Year");
                case 4:
                    return QString("Credits");
                case 5:
                    return QString("Major");
                case 6:
                    return QString("Advisor");
                }
            }
        }
        return QVariant();
    }
}

int adviseeModel::rowCount(const QModelIndex &parent) const
{
    return advisees.size();
}

int adviseeModel::columnCount(const QModelIndex &parent) const
{
    return 7;
}

QVariant adviseeModel::data(const QModelIndex &index, int role) const
{
    // Get the row and columns numbers from the given index (QModelIndex)
    int row = index.row();
    int col = index.column();

    // Qt::DisplayRole -> what data do we display and in what columns?
    if (role == Qt::DisplayRole)
    {
        switch (col)
        {
        case 0: // First Name column
            return QString::fromStdString(advisees[row].getFName());
            break;
        case 1: // Last Name column
            return QString::fromStdString(advisees[row].getLName());
            break;
        case 2: // ID column
            return QString::fromStdString(advisees[row].getID());
            break;
        case 3: // Class Year column
            return QString::fromStdString(advisees[row].getClassYear());
            break;
        case 4: // Credits column
            return QString::fromStdString(advisees[row].getCredits());
            break;
        case 5: // Major column
            return QString::fromStdString(advisees[row].getMajor());
            break;
        case 6: // Advisor name column
            return QString::fromStdString(advisees[row].getAdvisorName());
            break;
        }
    }

    // Qt::FontRole -> manages the fonts and font styles used in the View
    else if (role == Qt::FontRole)
    {
        // Bold the text in the first column
        if (col == 0) {
            QFont boldFont;
            boldFont.setBold(false);
            return boldFont;
        }
    }

    // Qt::ForegroundRole -> paints the foreground (text) colors
    else if (role == Qt::ForegroundRole)
    {
        // Paint the text red in the Password column
        if (col == 1) {
           return QBrush(QColor(0,0,0));
        }
    }

    // Qt::TextAlignRole -> controls how data is aligned inside cells
    else if(role == Qt::TextAlignmentRole)
    {
        // All columns after the Username column should be right-aligned
        // horizontally, and centered vertically.
        if (col > 0)
        {
            return Qt::AlignRight + Qt::AlignVCenter;
        }
    }
    return QVariant();
}

bool adviseeModel::setData(QModelIndex const& idx, QVariant const& value, int role)
{
  // Qt::EditRole: manages changes in the model
  if (Qt::EditRole == role)
  {
    // Get the top left and bottom right indices of the cells in our update range
    QModelIndex topLeft = idx;
    QModelIndex bottomRight = index(this->rowCount() - 1, this->columnCount() - 1);

    // VERY IMPORTANT - emit events telling all listening event handlers
    // that both the data (from cell 0,0 to the end) AND the layout have changed
    emit dataChanged(topLeft, bottomRight);
    emit layoutChanged();

    return true;
  }
  return false;
}
