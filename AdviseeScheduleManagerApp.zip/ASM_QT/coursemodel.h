#ifndef COURSEMODEL_H
#define COURSEMODEL_H

#include <QAbstractTableModel>
#include <vector>
#include <string>
#include <advisee.h>

using std::vector;
using std::string;

class courseModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vector<course> courses;

public:
    explicit courseModel(QObject *parent = 0);

    // Overrides methods inherited from QAbstractTableModel
    virtual int rowCount(const QModelIndex &parent = QModelIndex()) const;
    virtual int columnCount(const QModelIndex &parent = QModelIndex()) const;
    virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    virtual bool setData(const QModelIndex & index, const QVariant & value, int role = Qt::EditRole);

    void setCourses(vector<course>);
    void refreshSchedule();

signals:

private slots:
};

#endif // COURSEMODEL_H
